# ModuleProject-OD > 2023-10-14 5:33pm
https://universe.roboflow.com/nust-w6xwh/moduleproject-od

Provided by a Roboflow user
License: CC BY 4.0

